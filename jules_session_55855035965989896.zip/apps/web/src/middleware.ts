import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  const basicAuth = req.headers.get('authorization');
  const url = req.nextUrl;

  if (basicAuth) {
    const authValue = basicAuth.split(' ')[1];
    const [user, pwd] = atob(authValue).split(':');

    // Use environment variables for authentication, default to fallback for testing if missing
    const expectedUser = process.env.AUTH_USER || 'admin';
    const expectedPassword = process.env.AUTH_PASSWORD || 'superstorm';

    if (user === expectedUser && pwd === expectedPassword) {
      return NextResponse.next();
    }
  }

  url.pathname = '/api/auth';

  return new NextResponse('Authentication required', {
    status: 401,
    headers: {
      'WWW-Authenticate': 'Basic realm="Secure Area"',
    },
  });
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
